﻿(function() {
    if (window.mvcApp) {
        return;
    }
    window.mvcApp = {
        guid: {
            empty: '00000000-0000-0000-0000-000000000000'
        },
        ajax: {
            
        },
        notification: {
            
        },
        utils: {
            
        }
    };
    window.page = {
    
    };
})();