/**
 * Created by Leo on 2017/1/9.
 */
(function(){
    $(document).ready(function(){
       $("#navHome").addClass("selected");
    });
})();