package org.jframe.core.aliyun.mq;

/**
 * Created by leo on 2017-10-21.
 */
public interface MqTag {
    String getKey();
}
