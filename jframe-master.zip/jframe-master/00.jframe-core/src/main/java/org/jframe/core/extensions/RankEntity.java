package org.jframe.core.extensions;

/**
 * Created by leo on 2017-09-04.
 */
public interface RankEntity {
    void setRank(int rank);
}
