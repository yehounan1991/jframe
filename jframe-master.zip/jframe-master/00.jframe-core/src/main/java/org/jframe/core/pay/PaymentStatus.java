package org.jframe.core.pay;

/**
 * Created by Leo on 2017/11/9.
 */
public enum PaymentStatus {
    HTTP_ERROR,
    AWAITING,
    FAILED,
    SUCCESS;
}
