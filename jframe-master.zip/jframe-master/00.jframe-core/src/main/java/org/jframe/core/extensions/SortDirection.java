package org.jframe.core.extensions;

/**
 * Created by leo on 2017-05-26.
 */
public enum SortDirection {
    ASC,
    DESC;
}
