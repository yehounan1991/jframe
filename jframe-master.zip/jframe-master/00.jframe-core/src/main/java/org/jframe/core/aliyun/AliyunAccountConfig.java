package org.jframe.core.aliyun;

/**
 * Created by leo on 2017-10-21.
 */
public interface AliyunAccountConfig  {
    String getKey();
    String getSecret();
}
