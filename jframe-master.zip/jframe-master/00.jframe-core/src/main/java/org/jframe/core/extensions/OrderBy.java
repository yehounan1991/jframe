package org.jframe.core.extensions;

/**
 * Created by leo on 2017-06-13.
 */
public enum  OrderBy {
    asc,desc;
}
