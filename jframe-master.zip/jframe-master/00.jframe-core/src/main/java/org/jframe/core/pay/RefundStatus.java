package org.jframe.core.pay;

/**
 * created by yezi on 2018/4/13
 */
public enum RefundStatus {

    HTTP_ERROR,
    REFUND_PROCESSING,
    REFUND_SUCCESS,
    REFUND_FAIL;
}
