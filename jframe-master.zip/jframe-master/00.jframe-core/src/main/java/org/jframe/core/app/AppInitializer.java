package org.jframe.core.app;

/**
 * @author qq
 * @date 2018/6/25
 */
public interface AppInitializer {

    void initialize();
    void close();
}
