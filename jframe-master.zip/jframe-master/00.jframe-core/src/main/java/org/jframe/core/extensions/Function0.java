package org.jframe.core.extensions;

/**
 * Created by Leo on 2017/1/9.
 */
@FunctionalInterface
public interface Function0<TResult> {
    TResult apply();
}
