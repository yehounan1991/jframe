package org.jframe.web.core;

/**
 * Created by Leo on 2018/1/17.
 */
public interface AreaRegistration {
    void run() throws Exception;
}
