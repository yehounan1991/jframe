package org.jframe.core.unionpay.enums;

/**
 * Created by Leo on 2017/11/6.
 */
public enum SmsPayStatus {
    REQUEST_ERROR,
    REQUEST_SUCCESS,
    REQUEST_STATUS_UNKNOWN
}
