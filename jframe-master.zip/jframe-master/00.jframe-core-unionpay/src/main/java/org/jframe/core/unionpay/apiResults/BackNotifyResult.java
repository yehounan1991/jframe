package org.jframe.core.unionpay.apiResults;

/**
 * Created by Leo on 2017/11/6.
 */
public class BackNotifyResult extends FrontReturnResult {

    //从demo中的代码猜测，跟前台同步返回的参数一致，没有找到相关文档

}
