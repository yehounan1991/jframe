package org.jframe.infrastructure.configs;

/**
 * Created by Leo on 2017/10/20.
 */
public class HibernateConfig {
}
