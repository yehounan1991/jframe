package org.jframe.core.weixin.core.enums;

/**
 * Created by leo on 2017-09-23.
 */
public enum MediaType {
    image,
    voice,
    video,
    thumb,
    file,
    news
}
