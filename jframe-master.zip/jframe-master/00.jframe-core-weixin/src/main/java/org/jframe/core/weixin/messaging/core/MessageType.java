package org.jframe.core.weixin.messaging.core;

/**
 * Created by Leo on 2017/10/30.
 */
public enum MessageType {
    event,
    text,
    image,
    voice,
    video,
    shortvideo,
    location,
    link;
}
