package org.jframe.web.api.controllers;

import org.jframe.web.controllers._ControllerBase;

/**
 * Created by leo on 2017/5/7.
 */
public class _ApiControllerBase extends _ControllerBase {
}
